//java program to replace a substring inside a string by another one

public class ReplaceStringExample{  
public static void main(String args[]){  
String s1="google is a very good search engine";  
String replaceString=s1.replace('google','bing');//replaces all occurrences of 'google' to 'bing'  
System.out.println(replaceString);  
}}  