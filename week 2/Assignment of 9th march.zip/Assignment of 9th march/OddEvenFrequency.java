// find the frequency of odd and even numbers in the given matrix



// Importing Classes/Files
import java.io.*;

class OddEvenFrequency {

	// Function to compute frequency of odd/even numbers
	public static void findFreq(int[][] arr, int m, int n)
	{
		// Initializing the counter variables
		int even = 0, odd = 0;

		// Nested if loops
		// Traversing through each
		// element in the matrix
		for (int i = 0; i < m; i++) {
			
			for (int j = 0; j < n; j++) {

				// Checking if the element
				// is divisible by 2
				if (arr[i][j] % 2 == 0) {

					// Increment even counter
					even++;
				}
				else {

					// Increment odd counter
					odd++;
				}
			}
		}

		// Printing Counts of Enen
		// and odd numbers in matrix
		System.out.println("Odd Number Frequency: " + odd);
		System.out.println("Even Number Frequence: "
						+ even);
	}

	// Main Driver Method
	public static void main(String[] args)
	{
		// Providing inputs to the matrix
		int m = 3, n = 5;
		// Here, m = Number of rows,
		// n = Number of columns

		// Entering elements in the matrix
		int[][] arr = { { 3, 4, 5, 6, 3 },
						{ 4, 3, 2, 7, 9 },
						{ 1, 5, 7, 2, 4 } };

		// Calling function to count frequency by
		// passing inputs to the function findFreq
		findFreq(arr, m, n);
	}
}
