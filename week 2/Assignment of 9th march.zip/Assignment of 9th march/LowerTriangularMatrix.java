//lower tringular matrix

// Java program for displaying lower triangular matrix
import java.io.*;

class LowerTriangularMatrix {
	static void lowerTriangularMatrix(int matrix[][])
	{
		int row = matrix.length;
		int col = matrix[0].length;

		// if number of rows and columns are not equal,
		// then return back
		if (row != col) {
			System.out.println(
				"Matrix should be a Square Matrix");
			return;
		}
		else {
			// looping over the whole matrix
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++) {

					// for the rows,whose column number is
					// greater then row number,mark the
					// element as 0
					if (i < j) {
						matrix[i][j] = 0;
					}
				}
			}

			System.out.println(
				"Lower Triangular Matrix is given by :-");
			// printing the lower triangular matrix
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++) {
					System.out.print(matrix[i][j] + " ");
				}
				System.out.println();
			}
		}
	}
	public static void main(String[] args)
	{
		// driver code
		int mat[][]
			= { { 2, 1, 4 }, { 1, 2, 3 }, { 3, 6, 2 } };
		// calling the function
		lowerTriangularMatrix(mat);
	}
}
