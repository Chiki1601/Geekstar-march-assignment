//make an array with user inputs of size 10. then print count od all even numbers in an array

// Java Program to Count Even Numbers in an Array using Functions
import java.util.Scanner;

public class CountEveninArray {
	private static Scanner sc;
	public static void main(String[] args) 
	{
		int Size, i, evenCount = 0;
		sc = new Scanner(System.in);
	 
		System.out.print(" Please Enter Number of elements in an array : ");
		Size = sc.nextInt();	
		
		int [] a = new int[Size];
		
		System.out.print(" Please Enter " + Size + " elements of an Array  : ");
		for (i = 0; i < Size; i++)
		{
			a[i] = sc.nextInt();
		}   
		
		evenCount = CountEven(a, Size);
		System.out.println("\n Total Number of Even Numbers in this Array = " + evenCount);
	}
	public static int CountEven(int [] a, int Size)
	{
		int i, evenCount = 0;
		System.out.print("\n List of Even Numbers in this Array are :");  
		for(i = 0; i < Size; i++)
		{
			if(a[i] % 2 == 0)
			{
				System.out.print(a[i] +" ");
				evenCount++;
			}
		}
		return evenCount;
	}
}