//Write a method to Swap Two Numbers without using third variable

// Java Program to swap two numbers without
// using temporary variable
import java.io.*;

class Swapnumberswithoutthirdvariable {

	public static void main(String a[])
	{
		int x = 10;
		int y = 5;
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("After swapping:"
						+ " x = " + x + ", y = " + y);
	}
}


