// Create class named "Vehicle" with its basic characters as instance variables and basic functionalities as functions

class Vehicle {

    public Vehicle() {

        System.out.println("Vehicle created");
    }
}

class Bike extends Vehicle {
    
    public Bike() {
        
        // super();
        System.out.println("Bike created");
    }
 }

public class ImplicitSuper {

    public static void main(String[] args) {
        
        Bike bike = new Bike();
        System.out.println(bike);
    }
}