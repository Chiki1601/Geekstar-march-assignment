// create different objects like 1)bike 2)car, 3)trek


class Vehicle1 {
    
    protected double price;

    public Vehicle() {

        System.out.println("Vehicle created");
    }
    
    public Vehicle(double price) {
        
        this.price = price;

        System.out.printf("Vehicle created, price %.2f set%n", price);
    }    
}

class Bike extends Vehicle {
    
    public Bike() {
        
        super();
        System.out.println("Bike created");
    }
    
    public Bike(double price) {
        
        super(price);
        System.out.printf("Bike created, its price is: %.2f %n", price);
    }    
 }

public class SuperCalls {

    public static void main(String[] args) {
        
        Bike bike1 = new Bike();
        Bike bike2 = new Bike(45.90);
    }
}