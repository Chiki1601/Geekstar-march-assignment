//- initilize instance varibales of bike with no arguemnt default constructor
public class vehicle2 {

	// Instance field
	public String ownerName;
	public int licenseNumber;
	
	// Constructor
	public Bicycle( String name, int license ) {
		ownerName = name;
	  licenseNumber = license;
	}
	
   // Returns the name of this bicycle's owner
	public String getOwnerName( ) {
		
		return ownerName;
	}

	// Assigns the name of this bicycle's owner
	public void setOwnerName( String name ) {
	
		ownerName = name;
	}   

	// Returns the license number of this bicycle
	public int getLicenseNumber( ) {
		
		return licenseNumber;
	}

	// Assigns the license number of this bicycle
	public void setLicenseNumber( int number ) {
	
		licenseNumber = number;
	}	
 
 }