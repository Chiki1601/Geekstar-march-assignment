//create multiples objects like dog, cat, cow, elephant etc and demomnstrate various approches to assign values to variables


class Animal1{  
Animal(){System.out.println("animal is created");}  
}  
class Dog extends Animal{  
Dog(){  
System.out.println("dog is created");  
}  
}  
class Cat extends Animal{  
Dog(){  
System.out.println("cat is created");  
}  
}  
class Cow extends Animal{  
Dog(){  
System.out.println("cow is created");  
}  
} 
class Elephant extends Animal{  
Dog(){  
System.out.println("cow is created");  
}  
} 
class TestSuper4{  
public static void main(String args[]){  
Dog d=new Dog(); 
Cat c = new Cat();
Cow c1 = new Cow();
Elephant e = new Elephant();
 
}}  